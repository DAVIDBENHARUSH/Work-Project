package sanity;

import com.google.common.util.concurrent.Uninterruptibles;
import extansions.Verifications;
import org.openqa.selenium.Alert;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;
import pageObjects.CVPage;
import pageObjects.JobPage;
import utilities.CommonOps;
import workFlow.WebFlows;

import java.util.Set;
import java.util.concurrent.TimeUnit;

public class AllGobsTests extends CommonOps {

    @Test
    public void Test01_verifyHeader() {
        WebFlows.Main("Sbh135@walla.co.il", "Sbh24680");
        Verifications.verifyTextInElement(mainPage.Verify_title, "לוח דרושים: חיפוש עבודה בחינם");
    }

    @Test
    public void Test02_JobAutomation() {
        Uninterruptibles.sleepUninterruptibly(3, TimeUnit.SECONDS);
        WebFlows.JobAuto("Automation");
        Verifications.verifyTextInElement(jobPage.VerifyOpenJobs, "משרות Automation פנויות");
    }

    @Test
    public void Test03_JobSendCV() throws InterruptedException {
       Uninterruptibles.sleepUninterruptibly(3,TimeUnit.SECONDS);
        WebFlows.CVJobs("בית שאן");
        CVPage.SendCV();

            }
        }
