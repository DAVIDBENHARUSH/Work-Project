package extansions;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import utilities.CommonOps;

import java.util.List;

import static org.testng.Assert.assertEquals;

public class Verifications extends CommonOps {
    public static void verifyTextInElement(WebElement elem, String expected){
        wait.until(ExpectedConditions.visibilityOf(elem));
        assertEquals(elem.getText(),expected);
    }

    public static void numberOfElements(List<WebElement> elements, int expected){
        wait.until(ExpectedConditions.visibilityOf(elements.get(elements.size() -1)));
        assertEquals(elements.size(), expected);
    }

    public static void visibilityOfElements(List<WebElement> elems){
        for (WebElement elem : elems) {
            softAssert.assertTrue(elem.isDisplayed(),"i'm sorry" + elem.getText() + "not displayed");
        }
        softAssert.assertAll("Some elements is not displayed ");

    }
}
