package extansions;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import utilities.CommonOps;

import java.util.Set;

public class UIActions extends CommonOps {

    public static void click(WebElement elem) {
        wait.until(ExpectedConditions.elementToBeClickable(elem));
        elem.click();
    }

    public static void updateText(WebElement elem, String text) {
        try {
            wait.until((ExpectedConditions.visibilityOf(elem)));
            elem.sendKeys(text);
        } catch (TimeoutException e) {
            elem.sendKeys(text);
        }
    }

    public static void mouseHover(WebElement elem1, WebElement elem2) {
        action.moveToElement(elem1).moveToElement(elem2).click().build().perform();
    }

    public static void updateDropDown(WebElement elem, String text) {
        try {
            wait.until((ExpectedConditions.visibilityOf(elem)));
            Select dropDown = new Select(elem);
            dropDown.selectByVisibleText(text);
        } catch (TimeoutException e){

        }
    }

    public static void GetNewHandel(WebElement element, String text){
        Set<String> windowHandles = driver.getWindowHandles();
        for (String windowHandle : windowHandles) {
            driver.switchTo().window(windowHandle);
            if (driver.getTitle().equals("New Window Title")) {
                wait.until((ExpectedConditions.visibilityOf(element)));
                element.sendKeys(text);
            }
        }
    }
}