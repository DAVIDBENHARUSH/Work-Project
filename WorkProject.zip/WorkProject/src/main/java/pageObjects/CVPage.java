package pageObjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import utilities.CommonOps;

public class CVPage extends CommonOps {

    @FindBy(how = How.XPATH, using = "//*[@id='ContentPlaceHolder1_ucSearhRes_rptResults_resBox_0_UP1_0']/div/button[2]") // הגשת משרה
    public WebElement ClickDeveloper;
    @FindBy(how = How.ID, using = "ucSendCV_txtCity") // טופס מילוי פרטים עיר
    public WebElement txt_city;
    @FindBy(how = How.XPATH, using = "//*[@id='ucSendCV_fileDialog']") // כפתור CV קורות חיים
    public WebElement btn_CV;
    @FindBy(how = How.XPATH, using = "//*[@id='ucSendCV_divDistributeQ']/label/span") // אישור על איזורים להפצת קוח
    public WebElement btn_approve;
    @FindBy(how = How.XPATH, using = "//*[@id='ucSendCV_divDistributeS']/label[1]/span") // לחיצה על מרכז
    public WebElement btn_CentralArea;
    @FindBy(how = How.XPATH, using = "//*[@id='ucSendCV_btnSendCV']") // אישור שליחת קורות חיים
    public WebElement btn_sendCv;

    public static void SendCV(){
        WebElement fileInput = cvPage.btn_CV;
        String filePath = "\"C:\\Users\\97252\\Downloads\\קורות חיים דוד בן הרוש CV.docx\""; //קובץ קורות החיים שלי
        fileInput.sendKeys(filePath);
    }

}
