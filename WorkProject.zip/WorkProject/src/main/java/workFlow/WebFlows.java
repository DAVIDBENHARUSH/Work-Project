package workFlow;

import extansions.UIActions;
import utilities.CommonOps;

public class WebFlows extends CommonOps {

    public static void Main(String email, String pass){
        UIActions.click(mainPage.Btn_LoginMyProfile);
        UIActions.updateText(mainPage.txt_Email,email);
        UIActions.updateText(mainPage.txt_Pass,pass);
        UIActions.click(mainPage.btn_Login);

    }

    public static void JobAuto(String Search){
        UIActions.click(jobPage.JobSearch);
        UIActions.updateText(jobPage.txtSearch, Search);
        UIActions.click(jobPage.BtnGoSearch);
        UIActions.click(jobPage.SelectFromList);
    }

    public static void CVJobs(String city){
        UIActions.click(cvPage.ClickDeveloper);
        UIActions.GetNewHandel(cvPage.txt_city, city);
         UIActions.click(cvPage.btn_approve);
         UIActions.click(cvPage.btn_CentralArea);
         UIActions.click(cvPage.btn_sendCv);

    }



}
